/** Automatically generated file. DO NOT MODIFY */
package com.rucks.testlib;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}